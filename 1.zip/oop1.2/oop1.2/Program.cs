﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oop1_2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            double a = 7.0;
            double z = 3.4;
            double E = 2.0;
            double t = 11.5;
            
            double U = (35 / a) * z + z * a - ((a + E * t)/4);

            
            Console.WriteLine("Значение переменной a равно {0}", a);
            Console.WriteLine("Значение переменной z равно {0}", z);
            Console.WriteLine("Значение переменной E равно {0}", E);
            Console.WriteLine("Значение переменной t равно {0}", t);
            Console.WriteLine("Значение выражения U равно {0}", U);

            Console.ReadKey();
        }
    }
}