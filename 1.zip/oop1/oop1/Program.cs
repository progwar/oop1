﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oop1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторная работа №1");
            Console.WriteLine("");
            Console.WriteLine("Червиченко Иван Денисович");
            Console.WriteLine("");
            Console.WriteLine("Группа: ИВТ-б-о-24-2");
            Console.WriteLine("");
            Console.WriteLine("Д.Р: 07.10.2006");
            Console.WriteLine("");
            Console.WriteLine("Ставрополь");
            Console.WriteLine("");
            Console.WriteLine("Русский язык");
            Console.WriteLine("");
            Console.WriteLine("Музыка, игра на гитаре, баскетбол");

            Console.ReadKey();
        }
    }
}
